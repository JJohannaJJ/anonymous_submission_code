# GE-PEFT GATED EXPANDABLE PARAMETER- EFFICIENT FINE-TUNING FOR CONTINUAL LEARNING

This is the implementation code for GE-PEFT: Gated Expandable Parameter-Efficient Fine-Tuning for Continual Learning.

## Contents
The datasets and main methods for training specific models can be found in the src folder.

## Running
Scripts to run experiments with various models are available in the scripts folder.

For example, to start GE-PEFT experiments with the Llama 2 language model, run the GEPEFT_mask_exp_peft_orders_llama.sh script.


